package fr.luckyevent;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityExplodeEvent;

import java.util.Iterator;
import java.util.List;

public final class LuckyListener implements Listener {
    private final LuckyPlugin plugin;

    public LuckyListener(LuckyPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (plugin.luckyBlocks().isLuckyItem(e.getItemInHand())) {
            plugin.luckyBlocks().mark(e.getBlockPlaced());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!plugin.luckyBlocks().isLucky(b)) return;
        plugin.luckyBlocks().unmark(b);
        e.setDropItems(false);
        e.setExpToDrop(0);
        LootEntry entry = Loots.LUCKY.roll();
        entry.action().accept(new LootContext(e.getPlayer(), b.getLocation().add(0.5, 0.5, 0.5), false));
        e.getPlayer().sendActionBar(MiniMessage.miniMessage().deserialize("<gold>🎲 Lucky Block : <yellow>" + entry.name()));
    }

    // Explosions : le lucky block disparaît sans loot et ne drop pas d'item "normal"
    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        handleExplosion(e.blockList());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        handleExplosion(e.blockList());
    }

    private void handleExplosion(List<Block> blocks) {
        for (Iterator<Block> it = blocks.iterator(); it.hasNext(); ) {
            Block b = it.next();
            if (plugin.luckyBlocks().isLucky(b)) {
                plugin.luckyBlocks().unmark(b);
                it.remove();
                b.setType(Material.AIR);
            }
        }
    }

    // Pistons : on évite de déplacer un lucky block (la position enregistrée serait fausse)
    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (e.getBlocks().stream().anyMatch(plugin.luckyBlocks()::isLucky)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (e.getBlocks().stream().anyMatch(plugin.luckyBlocks()::isLucky)) e.setCancelled(true);
    }
}
