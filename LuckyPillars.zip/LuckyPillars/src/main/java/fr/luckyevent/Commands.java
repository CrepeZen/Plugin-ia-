package fr.luckyevent;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;

public final class Commands implements CommandExecutor, TabCompleter {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final LuckyPlugin plugin;

    public Commands(LuckyPlugin plugin) {
        this.plugin = plugin;
    }

    private void msg(CommandSender s, String mini) {
        s.sendMessage(MM.deserialize(mini));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("luckyblock.admin")) {
            msg(sender, "<red>Permission refusée.");
            return true;
        }
        return cmd.getName().equalsIgnoreCase("luckyblock") ? lucky(sender, args) : pillar(sender, args);
    }

    // /luckyblock give [joueur] [quantité]
    private boolean lucky(CommandSender sender, String[] args) {
        if (args.length == 0 || !args[0].equalsIgnoreCase("give")) {
            msg(sender, "<yellow>/luckyblock give [joueur] [quantité]");
            return true;
        }
        Player target = null;
        if (args.length >= 2) target = Bukkit.getPlayer(args[1]);
        else if (sender instanceof Player p) target = p;
        if (target == null) {
            msg(sender, "<red>Joueur introuvable.");
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try { amount = Math.max(1, Math.min(64, Integer.parseInt(args[2]))); }
            catch (NumberFormatException e) { msg(sender, "<red>Quantité invalide."); return true; }
        }
        target.getInventory().addItem(plugin.luckyBlocks().create(amount))
                .values().forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
        msg(sender, "<green>" + amount + " Lucky Block(s) donné(s) à " + target.getName());
        return true;
    }

    // /pillarevent <setcenter|join|leave|addall|start [secondes]|stop|status>
    private boolean pillar(CommandSender sender, String[] args) {
        PillarEvent ev = plugin.pillarEvent();
        if (args.length == 0) {
            msg(sender, "<yellow>/pillarevent <setcenter|join|leave|addall|start [secondes]|stop|status>");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "setcenter" -> {
                if (!(sender instanceof Player p)) { msg(sender, "<red>Joueur uniquement."); return true; }
                plugin.getConfig().set("event.center", p.getLocation().getBlock().getLocation());
                plugin.saveConfig();
                msg(sender, "<green>Centre de l'arène défini ici (les piliers partent de ce Y vers le haut).");
            }
            case "join" -> {
                if (!(sender instanceof Player p)) { msg(sender, "<red>Joueur uniquement."); return true; }
                msg(sender, ev.join(p) ? "<green>Inscrit à l'event." : "<red>Déjà inscrit ou event en cours.");
            }
            case "leave" -> {
                if (!(sender instanceof Player p)) { msg(sender, "<red>Joueur uniquement."); return true; }
                ev.leave(p);
                msg(sender, "<yellow>Tu as quitté l'event.");
            }
            case "addall" -> {
                int n = 0;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.equals(sender) || p.getGameMode() == GameMode.SPECTATOR) continue;
                    if (ev.join(p)) n++;
                }
                msg(sender, "<green>" + n + " joueur(s) inscrit(s) (organisateur exclu, utilise /pillarevent join pour participer).");
            }
            case "start" -> {
                int interval = plugin.getConfig().getInt("event.default-interval", 10);
                if (args.length >= 2) {
                    try { interval = Math.max(1, Integer.parseInt(args[1])); }
                    catch (NumberFormatException e) { msg(sender, "<red>Intervalle invalide."); return true; }
                }
                String err = ev.start(interval);
                msg(sender, err == null ? "<green>Event lancé (loot toutes les " + interval + "s)." : "<red>" + err);
            }
            case "stop" -> {
                ev.stop();
                msg(sender, "<yellow>Event arrêté, arène restaurée.");
            }
            case "status" -> msg(sender, "<gray>État : <white>" + ev.state() + " <gray>| inscrits : <white>"
                    + ev.registered().size() + " <gray>| en vie : <white>" + ev.aliveCount());
            default -> msg(sender, "<red>Sous-commande inconnue.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("luckyblock.admin")) return List.of();
        if (cmd.getName().equalsIgnoreCase("luckyblock")) {
            if (args.length == 1) return List.of("give");
            if (args.length == 2) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
            return List.of();
        }
        if (args.length == 1) {
            return List.of("setcenter", "join", "leave", "addall", "start", "stop", "status").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        }
        return List.of();
    }
}
