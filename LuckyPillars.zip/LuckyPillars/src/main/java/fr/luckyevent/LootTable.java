package fr.luckyevent;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Tirage pondéré : les poids sont normalisés (la somme n'a pas besoin de faire 100). */
public final class LootTable {
    private final List<LootEntry> entries;
    private final int total;

    public LootTable(List<LootEntry> entries) {
        this.entries = entries;
        this.total = entries.stream().mapToInt(LootEntry::weight).sum();
    }

    public LootEntry roll() {
        int r = ThreadLocalRandom.current().nextInt(total);
        for (LootEntry e : entries) {
            r -= e.weight();
            if (r < 0) return e;
        }
        return entries.getLast();
    }
}
