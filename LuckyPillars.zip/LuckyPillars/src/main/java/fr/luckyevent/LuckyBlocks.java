package fr.luckyevent;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.List;

/**
 * Lucky blocks : aucun craft. L'item porte un tag PDC, et chaque bloc posé est
 * enregistré dans le PDC de son chunk (persistant après redémarrage).
 */
public final class LuckyBlocks {
    private final LuckyPlugin plugin;
    private final NamespacedKey itemKey;
    private final NamespacedKey chunkKey;

    public LuckyBlocks(LuckyPlugin plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "lucky_item");
        this.chunkKey = new NamespacedKey(plugin, "lucky_blocks");
    }

    public ItemStack create(int amount) {
        Material m = Material.matchMaterial(plugin.getConfig().getString("lucky-block.material", "GOLD_BLOCK"));
        if (m == null || !m.isBlock()) m = Material.GOLD_BLOCK;
        ItemStack item = new ItemStack(m, amount);
        item.editMeta(meta -> {
            meta.displayName(Component.text("Lucky Block", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Casse-moi pour tenter ta chance !", NamedTextColor.YELLOW)
                    .decoration(TextDecoration.ITALIC, false)));
            meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        });
        return item;
    }

    public boolean isLuckyItem(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    private static long key(Block b) {
        return ((long) b.getY() << 8) | ((b.getX() & 15) << 4) | (b.getZ() & 15);
    }

    private long[] read(Chunk c) {
        long[] a = c.getPersistentDataContainer().get(chunkKey, PersistentDataType.LONG_ARRAY);
        return a == null ? new long[0] : a;
    }

    public boolean isLucky(Block b) {
        long k = key(b);
        for (long v : read(b.getChunk())) if (v == k) return true;
        return false;
    }

    public void mark(Block b) {
        if (isLucky(b)) return;
        long[] old = read(b.getChunk());
        long[] n = Arrays.copyOf(old, old.length + 1);
        n[old.length] = key(b);
        b.getChunk().getPersistentDataContainer().set(chunkKey, PersistentDataType.LONG_ARRAY, n);
    }

    public void unmark(Block b) {
        long k = key(b);
        long[] n = Arrays.stream(read(b.getChunk())).filter(v -> v != k).toArray();
        if (n.length == 0) b.getChunk().getPersistentDataContainer().remove(chunkKey);
        else b.getChunk().getPersistentDataContainer().set(chunkKey, PersistentDataType.LONG_ARRAY, n);
    }
}
