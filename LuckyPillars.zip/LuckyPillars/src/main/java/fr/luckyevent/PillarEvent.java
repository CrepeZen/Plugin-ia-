package fr.luckyevent;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;

/** Event admin : les joueurs inscrits sont téléportés sur des piliers de bedrock et reçoivent un loot toutes les X secondes. */
public final class PillarEvent implements Listener {
    public enum State { IDLE, COUNTDOWN, RUNNING }

    private record Snapshot(Location location, GameMode mode, ItemStack[] contents) {}

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final LuckyPlugin plugin;
    private final Set<UUID> registered = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Map<UUID, Snapshot> snapshots = new HashMap<>();
    private final Map<Block, BlockData> originalBlocks = new LinkedHashMap<>();

    private State state = State.IDLE;
    private boolean ending = false;
    private BukkitTask countdownTask, lootTask, endTask;

    public PillarEvent(LuckyPlugin plugin) {
        this.plugin = plugin;
    }

    public State state() { return state; }
    public Set<UUID> registered() { return registered; }
    public int aliveCount() { return alive.size(); }

    // ------------------------------------------------------------------ inscription
    public boolean join(Player p) {
        if (state != State.IDLE) return false;
        return registered.add(p.getUniqueId());
    }

    public void leave(Player p) {
        registered.remove(p.getUniqueId());
        if (snapshots.containsKey(p.getUniqueId())) {
            alive.remove(p.getUniqueId());
            restore(p);
            checkWin();
        }
    }

    // ------------------------------------------------------------------ démarrage
    public String start(int intervalSec) {
        if (state != State.IDLE) return "Un event est déjà en cours.";
        Location center = plugin.getConfig().getLocation("event.center");
        if (center == null || center.getWorld() == null) return "Centre non défini : /pillarevent setcenter";

        List<Player> players = new ArrayList<>();
        for (UUID id : registered) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) players.add(p);
        }
        if (players.size() < 2) return "Il faut au moins 2 joueurs inscrits en ligne.";

        List<Location> spawns = buildPillars(center, players.size());
        boolean clear = plugin.getConfig().getBoolean("event.clear-inventory", true);

        for (int i = 0; i < players.size(); i++) {
            Player p = players.get(i);
            snapshots.put(p.getUniqueId(), new Snapshot(p.getLocation(), p.getGameMode(), p.getInventory().getContents()));
            alive.add(p.getUniqueId());
            if (clear) p.getInventory().clear();
            p.setGameMode(GameMode.SURVIVAL);
            p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
            p.setFoodLevel(20);
            p.setSaturation(20f);
            p.setFireTicks(0);
            p.getActivePotionEffects().forEach(e -> p.removePotionEffect(e.getType()));
            p.teleport(spawns.get(i));
        }

        state = State.COUNTDOWN;
        ending = false;
        final int[] remaining = {plugin.getConfig().getInt("event.countdown", 10)};
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (remaining[0] <= 0) {
                countdownTask.cancel();
                state = State.RUNNING;
                broadcastToAlive("<green><bold>GO !</bold> <gray>Loot toutes les " + intervalSec + "s");
                lootTask = Bukkit.getScheduler().runTaskTimer(plugin, this::lootTick, 0L, intervalSec * 20L);
                return;
            }
            for (UUID id : alive) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.showTitle(Title.title(MM.deserialize("<gold>" + remaining[0]), Component.empty(),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
            }
            remaining[0]--;
        }, 0L, 20L);
        return null;
    }

    private List<Location> buildPillars(Location center, int n) {
        World w = center.getWorld();
        int cx = center.getBlockX(), cy = center.getBlockY(), cz = center.getBlockZ();
        int height = plugin.getConfig().getInt("event.pillar-height", 20);
        double radius = Math.max(plugin.getConfig().getDouble("event.min-radius", 10), Math.ceil(n * 3.0 / (2 * Math.PI)));
        int top = cy + height;

        List<Location> spawns = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            int x = cx + (int) Math.round(Math.cos(angle) * radius);
            int z = cz + (int) Math.round(Math.sin(angle) * radius);
            for (int y = cy; y <= top + 2; y++) {
                Block b = w.getBlockAt(x, y, z);
                originalBlocks.putIfAbsent(b, b.getBlockData());
                b.setType(y <= top ? Material.BEDROCK : Material.AIR, false);
            }
            Location spawn = new Location(w, x + 0.5, top + 1, z + 0.5);
            spawn.setDirection(new Location(w, cx + 0.5, top + 1, cz + 0.5).toVector().subtract(spawn.toVector()));
            spawns.add(spawn);
        }
        return spawns;
    }

    // ------------------------------------------------------------------ loot
    private void lootTick() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            LootEntry entry = Loots.AUTO.roll();
            entry.action().accept(new LootContext(p, p.getLocation(), true));
            p.sendActionBar(MM.deserialize("<gold>🎁 <yellow>" + entry.name()));
        }
    }

    // ------------------------------------------------------------------ arrêt
    public void stop() {
        if (countdownTask != null) countdownTask.cancel();
        if (lootTask != null) lootTask.cancel();
        if (endTask != null) endTask.cancel();
        countdownTask = lootTask = endTask = null;

        for (UUID id : new ArrayList<>(snapshots.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) restore(p);
        }
        snapshots.clear();
        alive.clear();

        originalBlocks.forEach((b, data) -> b.setBlockData(data, false));
        originalBlocks.clear();

        state = State.IDLE;
        ending = false;
    }

    private void restore(Player p) {
        Snapshot s = snapshots.remove(p.getUniqueId());
        if (s == null) return;
        p.getInventory().clear();
        p.getInventory().setContents(s.contents());
        p.getActivePotionEffects().forEach(e -> p.removePotionEffect(e.getType()));
        p.setFireTicks(0);
        p.setGameMode(s.mode());
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.teleport(s.location());
    }

    private void checkWin() {
        if (state != State.RUNNING || ending || alive.size() > 1) return;
        ending = true;
        if (lootTask != null) lootTask.cancel();
        if (alive.isEmpty()) {
            Bukkit.broadcast(MM.deserialize("<red>Event terminé : égalité !"));
        } else {
            Player w = Bukkit.getPlayer(alive.iterator().next());
            Bukkit.broadcast(MM.deserialize("<gold><bold>🏆 " + (w != null ? w.getName() : "?") + " remporte l'event !"));
        }
        endTask = Bukkit.getScheduler().runTaskLater(plugin, this::stop, 100L);
    }

    private void broadcastToAlive(String mini) {
        Component c = MM.deserialize(mini);
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendMessage(c);
        }
    }

    // ------------------------------------------------------------------ listeners
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!alive.contains(p.getUniqueId())) return;
        e.getDrops().clear();          // le loot d'event ne tombe pas
        e.setKeepInventory(false);
        e.setDroppedExp(0);
        alive.remove(p.getUniqueId());
        Bukkit.broadcast(MM.deserialize("<red>☠ " + p.getName() + " est éliminé ! <gray>(" + alive.size() + " restants)"));
        checkWin();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Snapshot s = snapshots.get(p.getUniqueId());
        if (s == null || alive.contains(p.getUniqueId())) return;
        e.setRespawnLocation(s.location());
        Bukkit.getScheduler().runTask(plugin, () -> restore(p));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (snapshots.containsKey(p.getUniqueId())) {
            alive.remove(p.getUniqueId());
            restore(p);
            checkWin();
        }
        registered.remove(p.getUniqueId());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (state == State.COUNTDOWN && e.getEntity() instanceof Player p && alive.contains(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }
}
