package fr.luckyevent;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

/** Contexte d'un tirage : en event le loot va dans l'inventaire, sur un lucky block il tombe au sol. */
public record LootContext(Player player, Location location, boolean toInventory) {

    public World world() {
        return location.getWorld();
    }

    public void give(ItemStack item) {
        if (toInventory && player != null) {
            EquipmentSlot slot = item.getType().getEquipmentSlot();
            boolean armor = slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST
                    || slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET;
            if (armor) {
                ItemStack current = player.getInventory().getItem(slot);
                if (current == null || current.getType().isAir()) {
                    player.getInventory().setItem(slot, item);
                    return;
                }
            }
            Map<Integer, ItemStack> left = player.getInventory().addItem(item);
            left.values().forEach(i -> world().dropItemNaturally(player.getLocation(), i));
        } else {
            world().dropItemNaturally(location, item);
        }
    }
}
