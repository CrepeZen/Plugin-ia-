package fr.luckyevent;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

public final class Loots {
    private Loots() {}

    /** Loot automatique de l'event piliers. */
    public static final LootTable AUTO = new LootTable(auto());
    /** Table des Lucky Blocks. */
    public static final LootTable LUCKY = new LootTable(lucky());

    // ---------- helpers ----------
    private static LootEntry items(int w, String name, Supplier<ItemStack[]> s) {
        return new LootEntry(w, name, c -> { for (ItemStack i : s.get()) c.give(i); });
    }

    private static LootEntry item(int w, String name, Material m, int amount) {
        return items(w, name, () -> new ItemStack[]{new ItemStack(m, amount)});
    }

    private static LootEntry effect(int w, String name, PotionEffectType t, int seconds, int amplifier) {
        return new LootEntry(w, name, c -> {
            if (c.player() != null) c.player().addPotionEffect(new PotionEffect(t, seconds * 20, amplifier));
        });
    }

    private static LootEntry healing(int w) {
        return items(w, "2 potions de soin", () -> {
            ItemStack[] potions = new ItemStack[2];
            for (int i = 0; i < 2; i++) {
                ItemStack p = new ItemStack(Material.POTION);
                p.editMeta(PotionMeta.class, m -> m.setBasePotionType(PotionType.HEALING));
                potions[i] = p;
            }
            return potions;
        });
    }

    private static LootEntry bow(int w) {
        return items(w, "Arc + 16 flèches",
                () -> new ItemStack[]{new ItemStack(Material.BOW), new ItemStack(Material.ARROW, 16)});
    }

    private static LootEntry lightning(int w) {
        return new LootEntry(w, "Foudre", c -> c.world().strikeLightning(c.location()));
    }

    private static LootEntry explosion(int w) {
        // pas de destruction de blocs : les piliers restent intacts
        return new LootEntry(w, "Explosion", c -> c.world().createExplosion(c.location(), 3f, false, false));
    }

    private static LootEntry mobs(int w) {
        return new LootEntry(w, "Mobs hostiles !", c -> {
            EntityType[] pool = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
                    EntityType.CREEPER, EntityType.WITCH};
            ThreadLocalRandom r = ThreadLocalRandom.current();
            int n = r.nextInt(3, 6);
            for (int i = 0; i < n; i++) {
                Location l = c.location().clone().add(r.nextDouble(-2, 2), 0, r.nextDouble(-2, 2));
                c.world().spawnEntity(l, pool[r.nextInt(pool.length)]);
            }
        });
    }

    private static LootEntry jackpot(int w) {
        return items(w, "JACKPOT !", () -> {
            ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
            sword.addUnsafeEnchantment(Enchantment.SHARPNESS, 3);
            return new ItemStack[]{sword, new ItemStack(Material.NETHERITE_CHESTPLATE),
                    new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 2), new ItemStack(Material.TOTEM_OF_UNDYING)};
        });
    }

    // ---------- tables ----------
    private static List<LootEntry> auto() {
        List<LootEntry> l = new ArrayList<>();
        l.add(item(12, "2 pommes dorées", Material.GOLDEN_APPLE, 2));
        l.add(healing(10));
        l.add(item(8, "4 ender pearls", Material.ENDER_PEARL, 4));
        l.add(item(7, "Casque en fer", Material.IRON_HELMET, 1));
        l.add(item(7, "Bottes en fer", Material.IRON_BOOTS, 1));
        l.add(item(6, "Plastron en fer", Material.IRON_CHESTPLATE, 1));
        l.add(item(6, "Jambières en fer", Material.IRON_LEGGINGS, 1));
        l.add(item(6, "Épée en fer", Material.IRON_SWORD, 1));
        l.add(item(5, "Casque en diamant", Material.DIAMOND_HELMET, 1));
        l.add(item(4, "Plastron en diamant", Material.DIAMOND_CHESTPLATE, 1));
        l.add(item(4, "Jambières en diamant", Material.DIAMOND_LEGGINGS, 1));
        l.add(item(4, "Bottes en diamant", Material.DIAMOND_BOOTS, 1));
        l.add(item(4, "Épée en diamant", Material.DIAMOND_SWORD, 1));
        l.add(bow(3));
        l.add(effect(3, "Force I (20s)", PotionEffectType.STRENGTH, 20, 0));
        l.add(effect(2, "Vitesse II (20s)", PotionEffectType.SPEED, 20, 1));
        l.add(effect(2, "Régénération (10s)", PotionEffectType.REGENERATION, 10, 0));
        l.add(effect(2, "Slowness II (15s)", PotionEffectType.SLOWNESS, 15, 1));
        l.add(effect(2, "Weakness (20s)", PotionEffectType.WEAKNESS, 20, 0));
        l.add(effect(1, "Poison (8s)", PotionEffectType.POISON, 8, 0));
        l.add(lightning(1));
        l.add(explosion(1));
        return l;
    }

    private static List<LootEntry> lucky() {
        List<LootEntry> l = new ArrayList<>();
        l.add(item(10, "2 pommes dorées", Material.GOLDEN_APPLE, 2));
        l.add(healing(8));
        l.add(item(7, "8 ender pearls", Material.ENDER_PEARL, 8));
        l.add(item(6, "Casque en fer", Material.IRON_HELMET, 1));
        l.add(item(6, "Plastron en fer", Material.IRON_CHESTPLATE, 1));
        l.add(item(6, "Jambières en fer", Material.IRON_LEGGINGS, 1));
        l.add(item(6, "Bottes en fer", Material.IRON_BOOTS, 1));
        l.add(item(5, "Casque en diamant", Material.DIAMOND_HELMET, 1));
        l.add(item(4, "Plastron en diamant", Material.DIAMOND_CHESTPLATE, 1));
        l.add(item(4, "Jambières en diamant", Material.DIAMOND_LEGGINGS, 1));
        l.add(item(4, "Bottes en diamant", Material.DIAMOND_BOOTS, 1));
        l.add(item(4, "Épée en diamant", Material.DIAMOND_SWORD, 1));
        l.add(bow(4));
        l.add(effect(4, "Force I (20s)", PotionEffectType.STRENGTH, 20, 0));
        l.add(effect(3, "Vitesse II (20s)", PotionEffectType.SPEED, 20, 1));
        l.add(effect(3, "Régénération (10s)", PotionEffectType.REGENERATION, 10, 0));
        l.add(effect(4, "Slowness II (15s)", PotionEffectType.SLOWNESS, 15, 1));
        l.add(effect(3, "Weakness (20s)", PotionEffectType.WEAKNESS, 20, 0));
        l.add(effect(2, "Poison (8s)", PotionEffectType.POISON, 8, 0));
        l.add(lightning(2));
        l.add(explosion(2));
        l.add(mobs(1));
        l.add(jackpot(1));
        return l;
    }
}
