package fr.luckyevent;

import org.bukkit.plugin.java.JavaPlugin;

public final class LuckyPlugin extends JavaPlugin {
    private LuckyBlocks luckyBlocks;
    private PillarEvent pillarEvent;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        luckyBlocks = new LuckyBlocks(this);
        pillarEvent = new PillarEvent(this);

        getServer().getPluginManager().registerEvents(new LuckyListener(this), this);
        getServer().getPluginManager().registerEvents(pillarEvent, this);

        Commands cmds = new Commands(this);
        getCommand("luckyblock").setExecutor(cmds);
        getCommand("luckyblock").setTabCompleter(cmds);
        getCommand("pillarevent").setExecutor(cmds);
        getCommand("pillarevent").setTabCompleter(cmds);
    }

    @Override
    public void onDisable() {
        if (pillarEvent != null) pillarEvent.stop();
    }

    public LuckyBlocks luckyBlocks() { return luckyBlocks; }
    public PillarEvent pillarEvent() { return pillarEvent; }
}
