package fr.luckyevent;

import java.util.function.Consumer;

public record LootEntry(int weight, String name, Consumer<LootContext> action) {
}
